function initFightSection() {
    if ( $("#combat").size() ) {
        fightContext = new FightContext();

        $("#combattre").click(function () {

            //fightContext.fightRound();
            alert(fightContext.round)

        });
    }
}

function FightContext = {
    this.round = 1;
}

function getCharacterLife() {
    return $("section#stats #pnt_endurance_restante").text();
}

function getCharacterSkill() {
    return $("section#stats #nb_pnt_attaque").text();
}

function getCharacterGold() {
    return $("section#stats #nb_pieces_or").text();
}

function getCharacterDisciplines() {
    return $("section#stats #disciplines li");
}

function getCharacterItems() {
    return $("section#sac_a_dos li");
}

$(document).ready( function() {

    //initFightSection();
    //alert(1);
    // Si un combat se trouve dans la page
    if ( $("#combat").size() ) {
        //Set page for combat
        $("section#decision").css("display", "none");
        $("section#combat ~ p").css("display", "none");
    }
	
    // Action a exécuté lorsque l'utilisateur désire changer de page
    $("section#decision a").click( function() {
        var pageNumberId = $(this).attr("id");

        var disciplinesArray = [];
        jQuery.each(getCharacterDisciplines(), function(index, value) {
        	disciplinesArray.push('"' + $(value).text() + '"');
        });

        var itemsArray = []
        jQuery.each(getCharacterItems(), function(index, value) {
        	itemsArray.push('"' + $(value).text() + '"');
        });

        //"23"

        $('form#invisibleForm input[name="characterLife"]').val(getCharacterLife());
        $('form#invisibleForm input[name="characterSkill"]').val(getCharacterSkill());
        $('form#invisibleForm input[name="characterGold"]').val(getCharacterGold());
        $('form#invisibleForm input[name="characterDisciplines"]').val("[" + disciplinesArray + "]");
        $('form#invisibleForm input[name="characterItems"]').val("[" + itemsArray + "]");

        $('form#invisibleForm input[name="currentPage"]').val(pageNumberId);
        $('form#invisibleForm input[name="oldNodes"]').val("[]");

        $('#invisibleForm').submit();
    });

});