var currentCharacter = null;

// make fight result function
// @param[in]   Int e: enemy damage
// @param[in]   Int l: lonewolf damage
function mfr(e, l) { return function (context) { context.characterDmg = l; context.monsterDmg = e; }; };
// make fight result function for automatic death of lonewolf
var mfrdl = function (context) { context.characterDmg = context.character.healthPoints; context.monsterDmg = 0; };
// make fight result function for automatic death of the enemy
var mfrde = function (context) { context.characterDmg = 0; context.monsterDmg = context.monster.healthPoints; };

// fight table for the game, do not attempt to read,
// relation between index and combat ratio :    if CR>=0      Math.Ceil(CR/2)+6      else     Math.Floor(CR/2)+6
// if CR < -11 then CR = -11    && if CR > 11 then CR = 11
var FightTable = [
[mfr(6, 0), mfrdl, mfrdl, mfr(0, 8), mfr(0, 8), mfr(1, 7), mfr(2, 6), mfr(3, 5), mfr(4, 4), mfr(5, 3), ],              // index 0, Combat Ratio -11 or less
[mfr(7, 0), mfrdl, mfr(0, 8), mfr(0, 7), mfr(1, 7), mfr(2, 6), mfr(3, 6), mfr(4, 5), mfr(5, 4), mfr(6, 3), ],          // index 1, Combat Ratio -10 & -9
[mfr(8, 0), mfr(0, 8), mfr(0, 7), mfr(1, 6), mfr(2, 6), mfr(3, 5), mfr(4, 5), mfr(5, 4), mfr(6, 3), mfr(7, 2), ],      // index 2, Combat Ratio -8 & -7
[mfr(9, 0), mfr(0, 6), mfr(1, 6), mfr(2, 5), mfr(3, 5), mfr(4, 4), mfr(5, 4), mfr(6, 3), mfr(7, 2), mfr(8, 0), ],      // index 3, Combat Ratio -6 & -5
[mfr(10, 0), mfr(1, 6), mfr(2, 5), mfr(3, 5), mfr(4, 4), mfr(5, 4), mfr(6, 3), mfr(7, 2), mfr(8, 1), mfr(9, 0), ],     // index 4, Combat Ratio -3 & -4
[mfr(11, 0), mfr(2, 5), mfr(3, 5), mfr(4, 4), mfr(5, 4), mfr(6, 3), mfr(7, 2), mfr(8, 2), mfr(9, 1), mfr(10, 0), ],    // index 5, Combat Ratio -1 & -2
[mfr(12, 0), mfr(3, 5), mfr(4, 4), mfr(5, 4), mfr(6, 3), mfr(7, 2), mfr(8, 2), mfr(9, 1), mfr(10, 0), mfr(11, 0), ],   // index 6, Combat Ratio 0
[mfr(14, 0), mfr(4, 5), mfr(5, 4), mfr(6, 3), mfr(7, 3), mfr(8, 2), mfr(9, 2), mfr(10, 1), mfr(11, 0), mfr(12, 0), ],  // index 7, Combat Ratio 1 & 2
[mfr(16, 0), mfr(5, 4), mfr(6, 3), mfr(7, 3), mfr(8, 2), mfr(9, 2), mfr(10, 2), mfr(11, 1), mfr(12, 0), mfr(14, 0), ], // index 8, Combat Ratio 3 & 4
[mfr(18, 0), mfr(6, 4), mfr(7, 3), mfr(8, 3), mfr(9, 2), mfr(10, 2), mfr(11, 1), mfr(12, 0), mfr(14, 0), mfr(16, 0), ],// index 9, Combat Ratio 5 & 6
[mfrde, mfr(7, 4), mfr(8, 3), mfr(9, 2), mfr(10, 2), mfr(11, 2), mfr(12, 1), mfr(14, 0), mfr(16, 0), mfr(18, 0), ],    // index 10, Combat Ratio 7 & 8
[mfrde, mfr(8, 3), mfr(9, 3), mfr(10, 2), mfr(11, 2), mfr(12, 2), mfr(14, 1), mfr(16, 0), mfr(18, 0), mfrde, ],        // index 11, Combat Ratio 9 & 10
[mfrde, mfr(9, 3), mfr(10, 2), mfr(11, 2), mfr(12, 2), mfr(14, 1), mfr(16, 1), mfr(18, 0), mfrde, mfrde, ],            // index 12, Combat Ratio 11 and more
];

function initFightSection() {
    // Si un combat se trouve dans la page.
    if ( $("#combat").size() ) {

        fightContext = new FightContext();

        $("#combattre").click(function () {

            fightContext.fightRound();

        });
    }
}

function FightContext() {

    // Initialisation du contexte
    this.round = 1;

    this.randomNum = 0;

    var monsterName = $("#monster_name strong").text();
    var monsterHealth = $("#pnt_endurance_monstre").text();
    var monsterSkill = $("#pnt_attaque_monstre").text();

    this.monster = new Monster(monsterName, parseInt(monsterHealth), parseInt(monsterSkill));
    this.character = new Character("", 13, 21, 19, ["Foudroiement psychique","Ecran psychique","Nexus"], ["Poignard","Lanterne","Masse d'armes","Trois rations spéciales","Trois graines de feu"]);

    this.combatRatio = this.character.skillPoints - this.monster.skillPoints;

    //Set page for combat
    $("section#decision").hide();
    $("section#combat ~ p").hide();

    this.fightRound = function() {
        this.randomNum = Math.floor((Math.random()*10));

        var CR = this.combatRatio;

        if (CR < -11) {
            CR = -11;
        } else if (CR > 11) {
            CR = 11;
        }

        if (CR >= 0) {
            var iTable = Math.ceil(CR / 2) + 6;
        } else {
            var iTable = Math.floor(CR / 2) + 6;
        }

        FightTable[iTable][this.randomNum](this);

        this.character.healthPoints = this.character.healthPoints - this.characterDmg;
        this.monster.healthPoints = this.monster.healthPoints - this.monsterDmg;

        this.updateUI();

        // Game Over
        if (this.character.healthPoints <= 0) {
            this.character.healthPoints = 0;
            this.loseFight();
        }

        if (this.monster.healthPoints <= 0) {
            this.monster.healthPoints = 0;

            // prevent double death, player death is more important than winning fight of course
            if (this.character.healthPoints != 0) {
                this.winFight();
            }
        }

        this.round++;
    }

    this.updateUI = function() {
        var section = '<section><h3>Ronde combat: <span>' + this.round + '</span></h3><p>Ratio de combat: ' + this.combatRatio + "<br/>Chiffre aléatoire: " + this.randomNum + "</p><p>Ton enemi a obtenu <i>" + this.monsterDmg + "</i> dégâts -<br/>et a maintenant <i>" + this.monster.healthPoints + "</i> points d'endurance.</p><p>Lone Wolf a eu <i>" + this.characterDmg + "</i> dégâts -<br/>et a maintenant <i>" + this.character.healthPoints + "</i> points d'endurance.</p></section>";
        
        $("#combat .choixCombat").before(section);

        //Mettre à jour les données de la page
        $("#pnt_endurance_restante").text(this.character.healthPoints);
        $("#pnt_endurance_monstre").text(this.monster.healthPoints);
        $("section.choixCombat button#fuir").attr("disabled", false);
    }

    this.winFight = function() {
        $("#combat .choixCombat").before("<h3>Vous avez vaincu l'ennemi!!!</h3>");
        $("section#combat section.choixCombat").hide();
        $("section#decision").css("display", "block");
    }

    this.loseFight = function() {
        alert("You lost the fight!");
    }
}

function Monster(name, healthPoints, skillPoints) {
    this.name = name;
    this.healthPoints = healthPoints;
    this.skillPoints = skillPoints;
}

// Class Character
// Class to represent the character and it's properties
// @param[in]   String              name:           Name of the character
// @param[in]   Integer             skillsPoints:   Skills points of the character
// @param[in]   Integer             healthPoints:   Health points of the character
// @param[in]   Integer             goldPoints:     Gold points of the character  
// @param[in]   Array<Skill>        skills:         List of skills that the character has
// @param[in]   Array<Equipment>    equipment:      List of equipment that the character has
function Character(name, skillsPoints, healthPoints, gold, skills, equipment) {
    this.name = name;
    this.healthPoints = healthPoints;
    this.skillPoints = skillsPoints;
    this.gold = gold;
    this.skills = skills;
    this.equipment = equipment;
}

this.updateDecisionUI = function() {

    var requiredSkills = $("section#decision p i span");
    var requiredSkillsArray = [];
    jQuery.each(requiredSkills, function(index, value) {
        requiredSkillsArray.push($(value).text());
    });
alert(requiredSkillsArray);
    var disciplines = ["Foudroiement psychique","Ecran psychique","Nexus"]
/*
    requiredSkillsArray.filter(function(n) {
        return disciplines.indexOf(n) == -1
    });
alert(disciplines);
    for (i = 0; i < requiredSkill.length; i++) {
        var skill = requiredSkill[i].parent().parent().find("a");
        skill.removeAttr('href');
        skill.css("color", "gray");
    }*/
/*
    hasDiscipline = false;
    for (i = 0; i < disciplines.length; i++) {
            if ($(disciplines[i]).text() == requiredSkill.text()) {
                hasDiscipline = true;
            }
    }

    if (!hasDiscipline) {
            var linkWithSkill = $("section#decision p i + a");
            linkWithSkill.removeAttr('href');
            linkWithSkill.css("color", "gray");
    }
}

$(document).ready( function() {

    initFightSection();
	
    updateDecisionUI();

    // Action a exécuté lorsque l'utilisateur désire changer de page
    $("section#decision a").click( function() {
        var pageNumberId = $(this).attr("id");

        var characterHealth = $("section#stats #pnt_endurance_restante").text();
        var characterSkill = $("section#stats #nb_pnt_attaque").text();
        var characterGold = $("section#stats #nb_pieces_or").text();
        var characterDisciplines = $("section#stats #disciplines li");
        var characterItems = $("section#sac_a_dos li");

        var disciplinesArray = [];
        jQuery.each(characterDisciplines, function(index, value) {
        	disciplinesArray.push('"' + $(value).text() + '"');
        });

        var itemsArray = []
        jQuery.each(characterItems, function(index, value) {
        	itemsArray.push('"' + $(value).text() + '"');
        });

        //"21"

        $('form#invisibleForm input[name="characterLife"]').val(characterHealth);
        $('form#invisibleForm input[name="characterSkill"]').val(characterSkill);
        $('form#invisibleForm input[name="characterGold"]').val(characterGold);
        $('form#invisibleForm input[name="characterDisciplines"]').val("[" + disciplinesArray + "]");
        $('form#invisibleForm input[name="characterItems"]').val("[" + itemsArray + "]");

        $('form#invisibleForm input[name="currentPage"]').val(pageNumberId);
        $('form#invisibleForm input[name="oldNodes"]').val("[135]");

        $('#invisibleForm').submit();
    });

});