$(document).ready( function() {
	
    $("a").click( function() {
        var attribut = $(this).attr("id");

        $('form#invisibleForm input[name="character"]').val(Character {pntHabilete = 10, pntEndurance = 10, piecesOr = 10, disciplines = ["Nexus","Intuition"], items = ["Carquois","Corde"]});

        $('#invisibleForm').submit();
    });

});